#include "stm32f10x.h"

void delay(int time);

int main(void){
	
	RCC -> APB2ENR |= 0x10;
	
	GPIOC -> CRH &= 0xFF0FFFFF;
	GPIOC -> CRH |= 0x00300000;
	
	GPIOC -> ODR |= 0x2000;
	
	while(1){
		GPIOC -> ODR |= 0x2000;
		delay(100);
		GPIOC -> ODR &= ~(0x2000);
		delay(100);
	}
	
	return 0;
}

void delay(int time){
	while(time){
		SysTick -> LOAD = 72000 - 1;
		SysTick -> VAL = 0;
		SysTick -> CTRL |= 5; // Chon CLOCK AHB -> Enable SysTick 
		while(!(SysTick -> CTRL & (1 << 16))){ //khi dem ve 0 bit 16 len 1 -> Dung tra ve TRUE, nhung ve truoc la phai khac TRUE 
																																		// -> ma TRUE = TRUE nen FALSE -> Ra khoi vong lap
		}
		time --; 
	}
}
