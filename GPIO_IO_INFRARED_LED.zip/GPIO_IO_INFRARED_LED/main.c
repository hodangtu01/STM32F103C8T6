#include "stm32f10x.h"

int read_infraded = 0;

int main(void){
	
	// INPUT: PB4 - PULL UP
	// ENABLE CLOCK PORT B
	RCC -> APB2ENR |= (1<<3); 
	
	// CONFIGURATION INPUT PORTB 4 - MODE: PULL UP
	GPIOB -> CRL &= (0<<16) | (0<<17) | (0<<18) | (0<<19); //~ (3UL << 16); //(0<<16) | (0<<17) | (0<<18) | (0<<19);
	GPIOB -> CRL |= (0<<16) | (0<<17) | (0<<18) | (1<<19); //(2UL << 18); //(0<<16) | (0<<17) | (0<<18) | (1<<19); // Input Pull Up/ Pull Down
	GPIOB -> ODR |= (1<<4);	// Using ODR to set up Pull Up Button PB4
	
	/// OUTPUT: PC13 - LED
	// ENABLE CLOCK PORT C
	RCC -> APB2ENR |= (1<<4);
	
	// CONFIGURATION OUTPUT PORTC 13 - MODE: PUSH-PULL
	GPIOC -> CRH |= (3UL << 20); //(0<<20) | (0<<21) | (0<<22) | (0<<23);
	GPIOC -> CRH &=~ (3UL << 22);  //(1<<20) | (1<<21) | (0<<22) | (0<<23);
	
	while(1){
		
//		read_infraded = (GPIOB ->IDR);
		if(((GPIOB -> IDR) & (1 << 4)) != 0){
			GPIOC -> ODR &=~  0x2000;
		}
		else{
			GPIOC -> ODR |= 0x2000;
	}
 }
}
